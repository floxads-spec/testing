import { createClient } from '@supabase/supabase-js';

export function db() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error('Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY');
  return createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
}

export function isAdmin(req: Request) {
  const expected = process.env.ADMIN_API_KEY;
  const supplied = req.headers.get('x-admin-key');
  return Boolean(expected && supplied && supplied.length === expected.length && timingSafeEqual(supplied, expected));
}
function timingSafeEqual(a: string, b: string) {
  let out = 0;
  for (let i = 0; i < a.length; i++) out |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return out === 0;
}

export async function sendMetaEvent(input: { eventName: string; eventId: string; sourceUrl: string; ip?: string; userAgent?: string; campaign?: string }) {
  const pixel = process.env.META_PIXEL_ID;
  const token = process.env.META_ACCESS_TOKEN;
  if (!pixel || !token) return { skipped: true };
  const userData: Record<string, string> = {};
  if (input.ip) userData.client_ip_address = input.ip;
  if (input.userAgent) userData.client_user_agent = input.userAgent;
  const body: Record<string, unknown> = {
    data: [{
      event_name: input.eventName,
      event_time: Math.floor(Date.now() / 1000),
      event_id: input.eventId,
      action_source: 'website',
      event_source_url: input.sourceUrl,
      user_data: userData,
      custom_data: { campaign: input.campaign || 'unknown', destination_type: 'telegram' }
    }]
  };
  if (process.env.META_TEST_EVENT_CODE) body.test_event_code = process.env.META_TEST_EVENT_CODE;
  const response = await fetch(`https://graph.facebook.com/v23.0/${encodeURIComponent(pixel)}/events?access_token=${encodeURIComponent(token)}`, {
    method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body), cache: 'no-store'
  });
  if (!response.ok) {
    const detail = await response.text();
    console.error('Meta CAPI error', response.status, detail.slice(0, 500));
    return { error: true };
  }
  return { ok: true };
}
