import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'Telegram Track | Campaign Analytics', description: 'Campaign click analytics and Telegram redirect tracking.' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en"><body>{children}</body></html>; }
