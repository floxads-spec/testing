import { NextResponse } from 'next/server';
import { db, isAdmin } from '@/lib/server';
export const runtime = 'nodejs';
export async function GET(req: Request) {
  if (!isAdmin(req)) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try { const { data, error } = await db().from('campaigns').select('id,name,slug,destination_url,created_at,clicks').order('created_at',{ascending:false}); if(error) throw error; return NextResponse.json({ campaigns:data||[] }); }
  catch(e) { console.error(e); return NextResponse.json({ error:'Could not load campaigns. Check Supabase setup.' },{status:500}); }
}
export async function POST(req: Request) {
  if (!isAdmin(req)) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const body = await req.json();
    const name = String(body.name || '').trim().slice(0,100);
    const slug = String(body.slug || '').trim().toLowerCase();
    const destination = String(body.destination_url || '').trim();
    if (!name || !/^[a-z0-9-]{3,50}$/.test(slug)) return NextResponse.json({error:'Name and a slug (3–50 lowercase letters, numbers or hyphens) are required.'},{status:400});
    let parsed: URL; try { parsed = new URL(destination); } catch { return NextResponse.json({error:'Enter a valid Telegram destination URL.'},{status:400}); }
    if (parsed.protocol !== 'https:' || !['t.me','telegram.me','www.t.me'].includes(parsed.hostname)) return NextResponse.json({error:'Destination must be an HTTPS Telegram link (t.me).'}, {status:400});
    const { data, error } = await db().from('campaigns').insert({name,slug,destination_url:parsed.toString()}).select('id,name,slug,destination_url,created_at,clicks').single();
    if(error) { if(error.code==='23505') return NextResponse.json({error:'That slug already exists.'},{status:409}); throw error; }
    return NextResponse.json({campaign:data}, {status:201});
  } catch(e) { console.error(e); return NextResponse.json({error:'Could not create campaign. Check database setup.'},{status:500}); }
}
