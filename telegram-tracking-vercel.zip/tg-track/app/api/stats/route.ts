import { NextResponse } from 'next/server';
import { db, isAdmin } from '@/lib/server';
export const runtime = 'nodejs';
export async function GET(req: Request) {
  if (!isAdmin(req)) return NextResponse.json({error:'Unauthorized'},{status:401});
  try {
    const client = db();
    const [{data:campaigns,error:e1},{data:events,error:e2}] = await Promise.all([
      client.from('campaigns').select('id,name,slug,destination_url,created_at,clicks').order('created_at',{ascending:false}),
      client.from('click_events').select('id,campaign_id,created_at,source,medium,campaign_tag,is_bot').order('created_at',{ascending:false}).limit(500)
    ]);
    if(e1) throw e1; if(e2) throw e2;
    const rows = events || [];
    return NextResponse.json({campaigns:campaigns||[], totalClicks:rows.filter(x=>!x.is_bot).length, botFiltered:rows.filter(x=>x.is_bot).length, recentEvents:rows.slice(0,100)});
  } catch(e) { console.error(e); return NextResponse.json({error:'Could not load analytics. Check Supabase schema.'},{status:500}); }
}
