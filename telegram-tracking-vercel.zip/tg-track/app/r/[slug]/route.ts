import { NextResponse } from 'next/server';
import { randomUUID } from 'node:crypto';
import { db, sendMetaEvent } from '@/lib/server';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
function looksLikeBot(ua: string) { return !ua || /bot|crawler|spider|preview|facebookexternalhit|meta-externalagent|WhatsApp|TelegramBot|Slackbot|Discordbot|Googlebot|bingbot/i.test(ua); }
export async function GET(req: Request, ctx: { params: Promise<{slug:string}> }) {
  const { slug } = await ctx.params;
  const url = new URL(req.url);
  try {
    const client = db();
    const {data:campaign,error} = await client.from('campaigns').select('id,slug,destination_url,name').eq('slug',slug).eq('active',true).maybeSingle();
    if(error || !campaign) return new Response('Tracking link not found or disabled.',{status:404,headers:{'content-type':'text/plain; charset=utf-8','cache-control':'no-store'}});
    const ua = req.headers.get('user-agent') || '';
    const bot = looksLikeBot(ua);
    const eventId = randomUUID();
    const params = url.searchParams;
    const source = (params.get('utm_source') || params.get('source') || '').slice(0,100);
    const medium = (params.get('utm_medium') || '').slice(0,100);
    const campaignTag = (params.get('utm_campaign') || '').slice(0,100);
    const forwarded = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim();
    const {error:insertError} = await client.from('click_events').insert({campaign_id:campaign.id,event_id:eventId,source,medium,campaign_tag:campaignTag,is_bot:bot,user_agent:ua.slice(0,500),referrer:(req.headers.get('referer')||'').slice(0,1000),ip_hash:forwarded ? await sha256(forwarded + (process.env.IP_HASH_SALT||'set-a-private-IP-HASH-SALT')) : null});
    if(insertError) console.error('Click event insert failed',insertError.message);
    if(!bot) {
      const {error:countError}=await client.rpc('increment_campaign_clicks',{campaign_id_input:campaign.id});
      if(countError) console.error('Click count update failed',countError.message);
      // Custom outbound-link event only. This is NOT a Telegram join/purchase/conversion.
      await sendMetaEvent({eventName:'TelegramLinkClick',eventId,sourceUrl:url.toString(),ip:forwarded,userAgent:ua,campaign:campaign.slug}).catch(e=>console.error('Meta CAPI failed',e));
    }
    const destination = new URL(campaign.destination_url);
    // Only preserve campaign attribution parameters, never arbitrary redirect targets.
    for (const key of ['utm_source','utm_medium','utm_campaign','utm_content','utm_term']) { const value=params.get(key); if(value) destination.searchParams.set(key,value.slice(0,100)); }
    return NextResponse.redirect(destination,302);
  } catch(e) { console.error(e); return new Response('Tracking temporarily unavailable.',{status:503,headers:{'content-type':'text/plain; charset=utf-8','cache-control':'no-store'}}); }
}
async function sha256(value:string) { const bytes = new TextEncoder().encode(value); const digest = await crypto.subtle.digest('SHA-256',bytes); return Array.from(new Uint8Array(digest)).map(b=>b.toString(16).padStart(2,'0')).join(''); }
