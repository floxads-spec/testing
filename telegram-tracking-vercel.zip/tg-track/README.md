# Telegram Tracking Dashboard (Next.js + Vercel + Supabase)

This is a deployable starter for campaign-specific Telegram redirect links, a private admin dashboard, click-event storage, basic user-agent bot filtering, and optional Meta Conversions API custom events.

## Important behavior
- Tracking URLs look like `https://YOUR-DOMAIN/r/campaign-slug?utm_source=facebook&utm_medium=paid_social&utm_campaign=spring`.
- Redirects only go to an HTTPS `t.me` / `telegram.me` URL stored by an authenticated admin. Arbitrary redirect targets are not accepted.
- The Meta event is `TelegramLinkClick`, a custom outbound-click event. It is NOT reported as a Telegram join, purchase, lead, or successful conversion.
- Telegram membership is not inferable from a link click. Measuring joins requires a separate Telegram Bot API design, bot admin permissions, and a privacy-aware joining flow; even then, available attribution is limited.
- Bot filtering is heuristic, not perfect. Do not claim it eliminates fake clicks. This starter intentionally does not auto-click, auto-subscribe, or fabricate conversion events.
- IP addresses are hashed with an optional salt before storage; the raw IP is only sent to Meta CAPI when configured. Consider local privacy rules, consent, and Meta policies before enabling.
- Dashboard metrics show the latest 500 events for the recent-events panel and are not lifetime unique-user counts.

## 1. Create Supabase database
1. Create a Supabase project.
2. Open SQL Editor and run the entire `supabase.sql` file.
3. Copy Project URL and service-role key from Project Settings > API. Keep the service-role key server-only.

## 2. Configure environment
Copy `.env.example` to `.env.local` and fill in:
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `ADMIN_API_KEY` (use a long random value)
- `APP_BASE_URL` (local URL during development; production URL after deploy)
- Optional `META_PIXEL_ID`, `META_ACCESS_TOKEN`, and `META_TEST_EVENT_CODE`
- Optional `IP_HASH_SALT` (add a long private random value)

Never prefix the service role key or Meta access token with `NEXT_PUBLIC_`. Do not commit `.env.local`.

## 3. Run locally
```bash
npm install
npm run dev
```
Open `http://localhost:3000/dashboard`, enter `ADMIN_API_KEY`, then create a campaign. Use a real Telegram invite link such as `https://t.me/yourpublicchannel` or `https://t.me/+YOUR_INVITE_HASH`.

## 4. Deploy to Vercel
1. Push this folder to a private GitHub repository.
2. Import the repository into Vercel.
3. Add the environment variables in Project Settings > Environment Variables for Production (and Preview/Development if needed).
4. Deploy/redeploy after changing environment variables.
5. Update `APP_BASE_URL` to the final HTTPS domain.
6. Test a campaign link and verify rows in Supabase.

## 5. Meta CAPI setup
In Meta Events Manager, use the Pixel/Dataset ID and a valid Conversions API access token. First add `META_TEST_EVENT_CODE` and check Test Events; remove the test code after validation. The server sends a custom `TelegramLinkClick` event only for requests that do not look like known crawlers. Review event diagnostics and data-use/consent requirements before production use.

## Security hardening before high traffic
- Protect the admin with real Supabase Auth / MFA rather than sharing one admin key among staff.
- Add rate limiting/WAF at the edge, alerting, retention rules, and abuse monitoring.
- Use separate Meta test and production configurations.
- Validate privacy notices and legal basis before sending personal data to Meta.
