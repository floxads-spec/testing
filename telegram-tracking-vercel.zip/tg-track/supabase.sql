-- Run this file in Supabase SQL Editor before deploying.
create extension if not exists pgcrypto;

create table if not exists public.campaigns (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  destination_url text not null,
  active boolean not null default true,
  clicks bigint not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.click_events (
  id uuid primary key default gen_random_uuid(),
  campaign_id uuid not null references public.campaigns(id) on delete cascade,
  event_id uuid not null unique,
  source text not null default '',
  medium text not null default '',
  campaign_tag text not null default '',
  is_bot boolean not null default false,
  user_agent text not null default '',
  referrer text not null default '',
  ip_hash text,
  created_at timestamptz not null default now()
);
create index if not exists click_events_campaign_created_idx on public.click_events(campaign_id, created_at desc);
create index if not exists click_events_created_idx on public.click_events(created_at desc);

-- All reads/writes in this starter use the server-side service role. Never expose that key in browser code.
alter table public.campaigns enable row level security;
alter table public.click_events enable row level security;
revoke all on public.campaigns from anon, authenticated;
revoke all on public.click_events from anon, authenticated;

create or replace function public.increment_campaign_clicks(campaign_id_input uuid)
returns void language sql security definer set search_path = public as $$
  update public.campaigns set clicks = clicks + 1 where id = campaign_id_input;
$$;
revoke all on function public.increment_campaign_clicks(uuid) from public, anon, authenticated;
grant execute on function public.increment_campaign_clicks(uuid) to service_role;
